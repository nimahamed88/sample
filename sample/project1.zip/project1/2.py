print (2)
i=0
for i in range(20):
	print (i)
print(1)
